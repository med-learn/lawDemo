var helpers = {
  isActive: function(a,b)
  {
    if(a==b)
     return "active";
    return "";
  },

  test: function()
  {
    return "file2";
  }



};

module.exports = helpers;
